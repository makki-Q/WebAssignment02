document.addEventListener("DOMContentLoaded", () => {
    loadCourses();
});

async function loadCourses() {
    try {
        const response = await fetch("/api/courses");
        const courses = await response.json();

        const courseList = document.getElementById("courseList");
        courseList.innerHTML = "";

        courses.forEach(course => {
            const listItem = document.createElement("li");
            listItem.innerHTML = `
                <img src="../images/course-icon.png" alt="Course Icon" class="course-img">
                <strong>${course.courseName}</strong> - ${course.availableSeats} seats
                <button onclick="deleteCourse('${course._id}')">Delete</button>
            `;
            courseList.appendChild(listItem);
        });
    } catch (error) {
        console.error("Error loading courses:", error);
    }
}

async function deleteCourse(courseId) {
    const token = localStorage.getItem("adminToken");

    try {
        const response = await fetch(`/api/courses/${courseId}`, {
            method: "DELETE",
            headers: { "Authorization": `Bearer ${token}` }
        });

        if (!response.ok) throw new Error("Failed to delete course");

        alert("Course deleted successfully!");
        loadCourses();
    } catch (error) {
        alert(error.message);
    }
}
