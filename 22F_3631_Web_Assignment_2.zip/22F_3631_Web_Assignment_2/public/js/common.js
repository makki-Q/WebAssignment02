document.addEventListener("DOMContentLoaded", function() {
    // Dynamically set image sources
    document.getElementById("logo").src = "images/logo.png";
    document.getElementById("profilePic").src = "images/profile-pic.png";
});
