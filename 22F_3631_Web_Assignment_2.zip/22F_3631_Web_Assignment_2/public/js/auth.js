document.addEventListener("DOMContentLoaded", () => {
    checkStudentSession();
});

async function studentLogin() {
    const rollNumber = document.getElementById("rollNumber").value.trim();
    const loginError = document.getElementById("loginError");

    loginError.textContent = "";

    if (!rollNumber) {
        loginError.textContent = "Please enter your roll number.";
        return;
    }

    try {
        const response = await fetch("/api/students/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ rollNumber })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message);

        localStorage.setItem("studentToken", data.token);
        window.location.href = "/student/dashboard.html";
    } catch (error) {
        loginError.textContent = error.message || "Login failed. Please try again.";
    }
}

function checkStudentSession() {
    if (localStorage.getItem("studentToken")) {
        window.location.href = "/student/dashboard.html";
    }
}
