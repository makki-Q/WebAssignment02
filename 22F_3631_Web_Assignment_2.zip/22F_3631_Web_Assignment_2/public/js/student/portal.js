document.addEventListener("DOMContentLoaded", () => {
    checkStudentSession();
    loadStudentCourses();
});

async function loadStudentCourses() {
    try {
        const response = await fetch("/api/courses");
        const courses = await response.json();

        const courseList = document.getElementById("student-course-list");
        courseList.innerHTML = "";

        courses.forEach(course => {
            const listItem = document.createElement("li");
            listItem.innerHTML = `
                <img src="../images/course-icon.png" alt="Course Icon" class="course-img">
                <strong>${course.courseName}</strong> - ${course.availableSeats} seats
                <button onclick="enrollCourse('${course._id}')">Enroll</button>
            `;
            courseList.appendChild(listItem);
        });
    } catch (error) {
        console.error("Error loading courses:", error);
    }
}

async function enrollCourse(courseId) {
    const token = localStorage.getItem("studentToken");

    try {
        const response = await fetch(`/api/students/enroll/${courseId}`, {
            method: "POST",
            headers: { "Authorization": `Bearer ${token}` }
        });

        if (!response.ok) throw new Error("Failed to enroll");

        alert("Enrolled successfully!");
        loadStudentCourses();
    } catch (error) {
        alert(error.message);
    }
}
