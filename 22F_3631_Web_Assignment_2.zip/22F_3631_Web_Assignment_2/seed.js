require("dotenv").config();
const mongoose = require("mongoose");
const Course = require("./models/course");

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch(err => console.error("MongoDB Connection Error:", err));

const seedCourses = async () => {
  try {
    await Course.deleteMany({});
    await Course.insertMany([
      { courseCode: "CS101", courseName: "Intro to CS", department: "CS", level: "1", timeSlot: "9 AM", days: ["Mon", "Wed"], availableSeats: 5 },
      { courseCode: "CS102", courseName: "Data Structures", department: "CS", level: "2", timeSlot: "11 AM", days: ["Tue", "Thu"], availableSeats: 3 }
    ]);
    console.log("✅ Courses Seeded!");
    mongoose.connection.close();
  } catch (error) {
    console.error("Error Seeding:", error);
    mongoose.connection.close();
  }
};

seedCourses();
