const express = require("express");
const router = express.Router();
const Student = require("../models/student");
const Course = require("../models/course");
const io = require("../server").io; // Import Socket.io instance
const authMiddleware = require("../middleware/authMiddleware"); // Import middleware

// 📌 Student Login Route
router.post("/login", async (req, res) => {
    try {
        const { rollNumber } = req.body;
        const student = await Student.findOne({ rollNumber });

        if (!student) {
            return res.status(401).json({ message: "Invalid roll number" });
        }

        // Generate JWT token
        const token = jwt.sign({ id: student._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

        res.json({ token, student });
    } catch (error) {
        res.status(500).json({ message: "Login failed", error });
    }
});

// 📌 Student Enrollment Route
router.post("/enroll/:courseId", authMiddleware, async (req, res) => {
    try {
        const studentId = req.student.id;
        const courseId = req.params.courseId;

        const course = await Course.findById(courseId);
        if (!course) return res.status(404).json({ message: "Course not found" });

        if (course.availableSeats <= 0) {
            return res.status(400).json({ message: "No seats available" });
        }

        const student = await Student.findById(studentId);
        if (!student) return res.status(404).json({ message: "Student not found" });

        if (student.enrolledCourses.includes(courseId)) {
            return res.status(400).json({ message: "Already enrolled" });
        }

        // Enroll student and update available seats
        student.enrolledCourses.push(courseId);
        course.availableSeats -= 1;

        await student.save();
        await course.save();

        res.json({ message: "Enrollment successful" });
    } catch (error) {
        res.status(500).json({ message: "Error enrolling", error });
    }
});
// 📌 Weekly Schedule (with conflict detection)
router.get("/schedule", authMiddleware, async (req, res) => {
    try {
        const student = req.student.populate("courses");
        const schedule = {};
        let conflictDetected = false;

        student.courses.forEach(course => {
            course.days.forEach(day => {
                if (!schedule[day]) {
                    schedule[day] = [];
                }

                // Check for conflicts
                const conflict = schedule[day].some(c => c.time === course.time);
                if (conflict) {
                    conflictDetected = true;
                }

                schedule[day].push(course);
            });
        });

        res.json({ schedule, conflictDetected });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

// 📌 Real-time Seat Availability
router.get("/courses/seats", async (req, res) => {
    try {
        const courses = await Course.find({}, "courseName availableSeats");
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

// 📌 Course Filtering System
router.get("/courses/filter", async (req, res) => {
    try {
        const { department, level, time, days, openSeats } = req.query;

        const filter = {};
        if (department) filter.department = department;
        if (level) filter.level = level;
        if (time) filter.time = time;
        if (days) filter.days = { $in: days.split(",") };
        if (openSeats) filter.availableSeats = { $gt: 0 };

        const courses = await Course.find(filter);
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

// 📌 Maintain Session State
router.post("/schedule/save", authMiddleware, async (req, res) => {
    try {
        const student = req.student;
        student.savedSchedule = req.body.courses; // Store selected courses
        await student.save();
        res.json({ message: "Schedule saved successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

// 📌 Show Prerequisites
router.get("/course/:id/prerequisites", async (req, res) => {
    try {
        const course = await Course.findById(req.params.id).populate("prerequisites");
        res.json(course.prerequisites);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

module.exports = router;
