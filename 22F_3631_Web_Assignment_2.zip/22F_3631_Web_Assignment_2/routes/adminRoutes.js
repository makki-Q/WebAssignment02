const express = require("express");
const router = express.Router();
const Admin = require("../models/admins");
const Course = require("../models/course");
const Student = require("../models/student");
const adminAuth = require("../middleware/adminAuth");

// 📌 Admin Login
router.post("/login", async (req, res) => {
    const { username, password } = req.body;
    try {
        const admin = await Admin.findOne({ username, password });
        if (!admin) {
            return res.status(401).json({ message: "Invalid credentials" });
        }
        res.json({ adminId: admin._id, message: "Login successful" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

// 📌 Add a Course
router.post("/courses", adminAuth, async (req, res) => {
    try {
        const newCourse = new Course(req.body);
        await newCourse.save();
        res.json({ message: "Course added successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error adding course", error });
    }
});

// 📌 Update a Course
router.put("/courses/:id", adminAuth, async (req, res) => {
    try {
        const updatedCourse = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedCourse) return res.status(404).json({ message: "Course not found" });
        res.json(updatedCourse);
    } catch (error) {
        res.status(500).json({ message: "Error updating course", error });
    }
});

// 📌 Delete a Course
router.delete("/courses/:id", adminAuth, async (req, res) => {
    try {
        const deletedCourse = await Course.findByIdAndDelete(req.params.id);
        if (!deletedCourse) return res.status(404).json({ message: "Course not found" });
        res.json({ message: "Course deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error deleting course", error });
    }
});

// 📌 View Student Registrations
router.get("/students", adminAuth, async (req, res) => {
    try {
        const students = await Student.find().populate("courses");
        res.json(students);
    } catch (error) {
        res.status(500).json({ message: "Error fetching students", error });
    }
});

// 📌 Override Student Registration
router.post("/students/:id/register", adminAuth, async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        if (!student) return res.status(404).json({ message: "Student not found" });

        student.courses.push(req.body.courseId);
        await student.save();

        res.json({ message: "Student registration overridden successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error overriding registration", error });
    }
});

// 📌 Adjust Course Seats
router.put("/courses/:id/seats", adminAuth, async (req, res) => {
    try {
        const course = await Course.findById(req.params.id);
        if (!course) return res.status(404).json({ message: "Course not found" });

        course.availableSeats = req.body.availableSeats;
        await course.save();

        res.json({ message: "Seats updated successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error updating seats", error });
    }
});

// 📌 Reports
router.get("/reports/courses/:id/students", adminAuth, async (req, res) => {
    try {
        const students = await Student.find({ courses: req.params.id });
        res.json(students);
    } catch (error) {
        res.status(500).json({ message: "Error fetching report", error });
    }
});

router.get("/reports/courses/available-seats", adminAuth, async (req, res) => {
    try {
        const courses = await Course.find({ availableSeats: { $gt: 0 } });
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Error fetching report", error });
    }
});

router.get("/reports/students/missing-prerequisites", adminAuth, async (req, res) => {
    try {
        const students = await Student.find();
        const studentsWithMissingPrereqs = students.filter(student =>
            student.courses.some(course => 
                course.prerequisites && !student.courses.includes(course.prerequisites)
            )
        );
        res.json(studentsWithMissingPrereqs);
    } catch (error) {
        res.status(500).json({ message: "Error fetching report", error });
    }
});

module.exports = router;
