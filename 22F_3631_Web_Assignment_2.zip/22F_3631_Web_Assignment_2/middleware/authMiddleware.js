const jwt = require("jsonwebtoken");
const Student = require("../models/student");
require("dotenv").config();

const authMiddleware = async (req, res, next) => {
    try {
        const token = req.header("Authorization")?.replace("Bearer ", "");
        if (!token) {
            return res.status(401).json({ message: "Access Denied. No Token Provided." });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const student = await Student.findById(decoded.id);
        if (!student) {
            return res.status(404).json({ message: "Student not found." });
        }

        req.student = student; // Attach student object to request
        next();
    } catch (error) {
        res.status(401).json({ message: "Invalid Token", error });
    }
};

module.exports = authMiddleware;
