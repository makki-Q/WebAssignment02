const Admin = require("../models/admins");

const adminAuth = async (req, res, next) => {
    try {
        const adminId = req.header("Admin-ID");
        if (!adminId) {
            return res.status(401).json({ message: "Access Denied. No Admin ID provided." });
        }

        const admin = await Admin.findById(adminId);
        if (!admin) {
            return res.status(404).json({ message: "Admin not found." });
        }

        req.admin = admin; // Attach admin object to request
        next();
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
};

module.exports = adminAuth;
